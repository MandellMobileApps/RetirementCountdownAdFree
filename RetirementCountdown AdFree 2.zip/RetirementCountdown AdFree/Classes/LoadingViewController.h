//
//  LoadingViewController.h
//  RetirementCountdown
//
//  Created by Jon Mandell on 10/16/10.
//  Copyright 2010 MandellMobileApps. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LoadingViewController : UIViewController {

}

@end
