//
//  CustomCellForColors.h
//  RetirementCountdown
//
//  Created by Jon Mandell on 11/22/09.
//  Copyright 2009 MandellMobileApps. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomCellForColors : UITableViewCell {

	IBOutlet UIButton *colorButton;

}

@property (nonatomic, retain) IBOutlet UIButton *colorButton;

@end
